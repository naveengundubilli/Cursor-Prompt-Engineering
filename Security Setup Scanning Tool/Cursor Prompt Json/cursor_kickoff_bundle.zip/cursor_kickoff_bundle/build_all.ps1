param()

$modules = @(
  @{ Name="secplatform-core"; Script="scripts\build.ps1" },
  @{ Name="secplatform-sast"; Script="scripts\build.ps1" },
  @{ Name="secplatform-iac"; Script="scripts\build.ps1" },
  @{ Name="secplatform-dashboard"; Script="scripts\build.ps1" }
)

$results = @()

foreach($m in $modules){
  $name = $m.Name
  $script = Join-Path $name $m.Script
  if(Test-Path $script){
    Write-Host "=== Building $name ==="
    $p = Start-Process -FilePath "powershell" -ArgumentList "-ExecutionPolicy Bypass -File `"$script`"" -NoNewWindow -PassThru -Wait
    $code = $p.ExitCode
    $results += @{ Name=$name; Code=$code }
  } else {
    Write-Warning "Skipping $name (missing $script)"
    $results += @{ Name=$name; Code=999 }
  }
}

Write-Host ""
Write-Host "===== SUMMARY ====="
$fail = $false
foreach($r in $results){
  if($r.Code -eq 0){
    Write-Host ("✅ " + $r.Name)
  } elseif ($r.Code -eq 999) {
    Write-Host ("⚠️  " + $r.Name + " (missing build script)")
  } else {
    Write-Host ("❌ " + $r.Name + " (exit " + $r.Code + ")")
    $fail = $true
  }
}

if($fail){ exit 1 } else { exit 0 }