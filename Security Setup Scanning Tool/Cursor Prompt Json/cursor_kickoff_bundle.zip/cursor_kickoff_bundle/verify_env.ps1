param()

Write-Host "=== Verifying Local Environment ==="

function Check-Cmd {
  param([string]$cmd, [string]$arg = "--version")
  try {
    $p = Start-Process -FilePath $cmd -ArgumentList $arg -NoNewWindow -PassThru -Wait -ErrorAction Stop
    Write-Host "Found: $cmd"
    return $true
  } catch {
    Write-Warning "Missing: $cmd"
    return $false
  }
}

$okJava = Check-Cmd "java" "-version"
$okNode = Check-Cmd "node" "--version"
$okNpm  = Check-Cmd "npm" "--version"
$okPwsh = $PSVersionTable.PSVersion.Major -ge 7

if(-not $okPwsh){ Write-Warning "PowerShell 7+ recommended. Current: $($PSVersionTable.PSVersion)" }

# Check Postgres default
try {
  $tcp = Test-NetConnection -ComputerName "localhost" -Port 5432 -WarningAction SilentlyContinue
  if($tcp.TcpTestSucceeded){ Write-Host "PostgreSQL port reachable on localhost:5432" }
  else { Write-Warning "PostgreSQL not reachable on localhost:5432" }
} catch { Write-Warning "Skipping PostgreSQL check." }

if(-not ($okJava -and $okNode -and $okNpm)){
  Write-Error "Environment not ready. Install missing tools and re-run."
  exit 1
}

Write-Host "Environment looks OK."
exit 0