# Cursor Kickoff — One-Paste Startup

## What this is
A single prompt (`cursor_super_prompt.txt`) and helper scripts so you can tell Cursor to **read the recipes** and **start the build** end-to-end.

## How to use
1. Download these folders/files into the root of your repository (same level as `.git/`):
   - `cursor_recipes_v2/` (the v2 JSON recipes you downloaded earlier)
   - `supplement_pack_v1/` (openapi.yaml, liquibase migrations, fixtures, prompt blocks)
   - `cursor_kickoff_bundle/` (this folder)
2. Open Cursor and paste the contents of `cursor_kickoff_bundle/cursor_super_prompt.txt` into a new chat.
3. When Cursor asks for missing files, drag/drop them from your file explorer into the workspace.
4. Cursor will:
   - Run `scripts/verify_env.ps1`
   - Scaffold each module from the recipes
   - Paste OpenAPI + Liquibase + fixtures exactly
   - Build and run local smoke tests
5. After generation, run at repo root:
   ```powershell
   powershell -ExecutionPolicy Bypass -File cursor_kickoff_bundle\build_all.ps1
   ```

## Notes
- Everything is **Windows-first** and avoids Docker for local dev.
- If your env is not ready, `verify_env.ps1` will tell you what to install.
- You can re-run the prompt to continue from any step; it’s idempotent.